var count=1;
var likeButton=document.querySelector("#count");

function addBy1(){
    count++;
    likeButton.innerText= count + " like(s)";
    console.log(count);
}

var count2=1;
var likeButton2=document.querySelector("#count2");

function addBy1_2(){
    count2++;
    likeButton2.innerText= count2 + " like(s)";
    console.log(count2);
}

var count3=1;
var likeButton3=document.querySelector("#count3");

function addBy1_3(){
    count3++;
    likeButton3.innerText= count3 + " like(s)";
    console.log(count3);
}