// alert("test");

function logOut(changeLog){
    changeLog.innerText = "Logged Out";
}

function say(){
    alert("Ninja was liked");
}

// function changeText(){
//     var aa = document.querySelector("#login-btn");
//     aa.innerHTML="Logged out";
// }

// function message(){
//     document.getElementById("btn-like");
//     alert("Ninja was liked");
// }

function hide(element){
   element.remove();
}
